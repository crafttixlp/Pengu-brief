#!/usr/bin/env bash
# Builds Pengu-Brief-x86_64.AppImage  /  Baut Pengu-Brief-x86_64.AppImage
#
# Requirements / Voraussetzungen: Linux x86_64, Python 3.10+ with Tkinter (Debian/Ubuntu: sudo apt install python3-tk python3-venv),
# internet access for pip and appimagetool.  Use PYTHON=/path/to/python to pick another interpreter.
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
OUT="Pengu-Brief-x86_64.AppImage"

"$PY" -c "import tkinter" 2>/dev/null || {
  echo "Tkinter is missing for $PY. Debian/Ubuntu: sudo apt install python3-tk  /  Tkinter fehlt: sudo apt install python3-tk" >&2
  exit 1
}

echo "==> Python environment"
"$PY" -m venv .venv
# shellcheck disable=SC1091
. .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo "==> PyInstaller"
rm -rf build dist AppDir "$OUT"
pyinstaller --noconfirm --clean --onedir --name pengu-brief --paths src \
  --collect-all customtkinter --hidden-import PIL.ImageTk --hidden-import PIL._tkinter_finder \
  --add-data "assets/pengu-brief.png:." src/app_main.py >build.log 2>&1 \
  || { tail -n 30 build.log >&2; echo "PyInstaller failed, see build.log" >&2; exit 1; }

echo "==> AppDir"
mkdir -p AppDir/usr/bin AppDir/usr/share/applications AppDir/usr/share/icons/hicolor/512x512/apps
cp -r dist/pengu-brief AppDir/usr/bin/
cp assets/pengu-brief.png AppDir/pengu-brief.png
cp assets/pengu-brief.png AppDir/.DirIcon
cp assets/pengu-brief.png AppDir/usr/share/icons/hicolor/512x512/apps/
cat > AppDir/pengu-brief.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=Pengu-Brief
GenericName=Project Summarizer
GenericName[de]=Projekt-Zusammenfasser
Comment=Summarize project folders compactly - for you and your AI agents
Comment[de]=Fasst Projektordner kompakt zusammen - für dich und deine KI-Agenten
Exec=pengu-brief
Icon=pengu-brief
Categories=Utility;Development;
Keywords=summary;project;AI;agent;MCP;LLM;Zusammenfassung;Projekt;KI;
Terminal=false
DESKTOP
cp AppDir/pengu-brief.desktop AppDir/usr/share/applications/
cat > AppDir/AppRun <<'APPRUN'
#!/bin/sh
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/pengu-brief/pengu-brief" "$@"
APPRUN
chmod +x AppDir/AppRun

echo "==> appimagetool"
if [ ! -x tools/appimagetool ]; then
  curl -fsSL -o tools/appimagetool \
    https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage
  chmod +x tools/appimagetool
fi
ARCH=x86_64 APPIMAGE_EXTRACT_AND_RUN=1 tools/appimagetool AppDir "$OUT" >/dev/null 2>&1

echo "==> Done / Fertig: $OUT ($(du -h "$OUT" | cut -f1))"

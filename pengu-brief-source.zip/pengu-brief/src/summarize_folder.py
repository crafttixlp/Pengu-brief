#!/usr/bin/env python3
"""
summarize_folder.py - fasst einen Projektordner zu einer kompakten Markdown-Datei zusammen.

Die Datei kann als Kontext für ein LLM dienen (z. B. als CLAUDE.md, AGENTS.md oder
System-Prompt), damit das Modell nicht jedes Mal alle Dateien neu lesen muss.

Nur Standardbibliothek, Python 3.8+ (ast.unparse ab 3.9 für schoene Signaturen).

Beispiele:
    python summarize_folder.py .
    python summarize_folder.py ~/projekte/meineapp -o CLAUDE.md
    python summarize_folder.py . --llm --model qwen3.6:35b-a3b      # Ollama (lokal)
    python summarize_folder.py . --llm --base-url http://localhost:1234/v1 --model mein-modell
"""
import argparse
import ast
import fnmatch
import json
import os
import re
import sys
import urllib.request
from collections import Counter
from pathlib import Path

from i18n import detect_lang, lang_from_argv

TEXTS = {
    "de": {
        "tree_files": "... ({n} Dateien)", "tree_more": "... (+{n} weitere)",
        "present": "**{name}** vorhanden", "docker_base": " Basis ", "docker_start": "; Start: `{cmd}`",
        "file_lines": "({n} Zeilen)", "title": "# Projekt: {name}",
        "generated": "_Automatisch erzeugt mit Pengu-Brief: {files} Dateien, ca. {lines} Zeilen._",
        "h_langs": "Sprachen", "lang_row": "- {lang}: {files} {fw}, {lines} {lw}", "w_file": ("Datei", "Dateien"), "w_line": ("Zeile", "Zeilen"),
        "h_info": "Projekt-Infos", "h_struct": "Struktur", "h_entry": "Einstiegspunkte",
        "h_modules": "Module und Schnittstellen",
        "skipped": "- ... {n} weitere Code-Dateien ohne Details",
        "no_files": "Keine Dateien gefunden.", "not_dir": "Kein Ordner: {p}",
        "h_llm": "Zusammenfassung (LLM)", "llm_ask": "Frage LLM nach Zusammenfassung ...",
        "llm_fail": "LLM-Aufruf fehlgeschlagen ({e}); schreibe nur die Strukturübersicht.",
        "written": "Geschrieben: {path} ({chars} Zeichen, ca. {tokens} Tokens)",
        "llm_system": "Du bist ein Senior-Entwickler und schreibst knappe Projekt-Dokumentation für andere LLMs.",
        "llm_prompt": ("Unten steht eine automatisch erzeugte Strukturübersicht eines Software-Projekts. "
                       "Schreibe daraus eine kompakte Einleitung auf Deutsch (max. 15 Zeilen) mit: "
                       "1) Zweck der Anwendung, 2) Architektur in Stichpunkten, 3) Wichtigste Ordner/Module "
                       "mit je einem Satz, 4) vermutete Konventionen. Erfinde nichts, was nicht aus der "
                       "Übersicht ableitbar ist.\n\n"),
        "p_desc": "Projektordner zu kompakter Markdown-Kontextdatei zusammenfassen.",
        "p_path": "Ordner (Standard: aktuelles Verzeichnis)", "p_out": "Ausgabedatei (relativ zum Ordner)",
        "p_depth": "Tiefe des Verzeichnisbaums", "p_entries": "Max. Einträge pro Ordner im Baum",
        "p_files": "Max. Code-Dateien mit Details", "p_items": "Max. Funktionen/Klassen pro Datei",
        "p_stdout": "Statt Datei auf stdout ausgeben", "p_llm": "Zusatzbeschreibung per LLM erzeugen lassen",
        "p_lang": "Sprache der Ausgabe (Standard: automatisch nach System-Sprache)",
    },
    "en": {
        "tree_files": "... ({n} files)", "tree_more": "... (+{n} more)",
        "present": "**{name}** present", "docker_base": " Base ", "docker_start": "; start: `{cmd}`",
        "file_lines": "({n} lines)", "title": "# Project: {name}",
        "generated": "_Generated automatically with Pengu-Brief: {files} files, approx. {lines} lines._",
        "h_langs": "Languages", "lang_row": "- {lang}: {files} {fw}, {lines} {lw}", "w_file": ("file", "files"), "w_line": ("line", "lines"),
        "h_info": "Project info", "h_struct": "Structure", "h_entry": "Entry points",
        "h_modules": "Modules and interfaces",
        "skipped": "- ... {n} more code files without details",
        "no_files": "No files found.", "not_dir": "Not a folder: {p}",
        "h_llm": "Summary (LLM)", "llm_ask": "Asking the LLM for a summary ...",
        "llm_fail": "LLM call failed ({e}); writing the structure overview only.",
        "written": "Written: {path} ({chars} characters, approx. {tokens} tokens)",
        "llm_system": "You are a senior developer and write concise project documentation for other LLMs.",
        "llm_prompt": ("Below is an automatically generated structure overview of a software project. "
                       "Write a compact introduction in English (max. 15 lines) covering: "
                       "1) purpose of the application, 2) architecture in bullet points, 3) the most important "
                       "folders/modules with one sentence each, 4) likely conventions. Do not invent anything "
                       "that cannot be derived from the overview.\n\n"),
        "p_desc": "Summarize a project folder into a compact Markdown context file.",
        "p_path": "Folder (default: current directory)", "p_out": "Output file (relative to the folder)",
        "p_depth": "Depth of the directory tree", "p_entries": "Max. entries per folder in the tree",
        "p_files": "Max. code files with details", "p_items": "Max. functions/classes per file",
        "p_stdout": "Print to stdout instead of writing a file", "p_llm": "Let an LLM write an additional introduction",
        "p_lang": "Output language (default: automatic, from the system language)",
    },
}
LANG = "en"


def set_lang(code=None) -> str:
    """Setzt die Ausgabesprache ('de'/'en'; None = automatisch)."""
    global LANG
    LANG = detect_lang(code)
    return LANG


def tr(key: str, **kw) -> str:
    return TEXTS[LANG][key].format(**kw)


def plural(key: str, n: int) -> str:
    one, many = TEXTS[LANG][key]
    return one if n == 1 else many


set_lang()

IGNORE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".idea", ".vscode", "dist", "build", "target", ".next", ".nuxt", ".cache",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", "coverage", ".gradle",
    "site-packages", ".terraform",
}
IGNORE_FILES = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock", "Cargo.lock",
    "Pipfile.lock", "composer.lock", ".DS_Store", "Thumbs.db",
}
LANGS = {
    ".py": "Python", ".js": "JavaScript", ".jsx": "JavaScript", ".ts": "TypeScript",
    ".tsx": "TypeScript", ".go": "Go", ".rs": "Rust", ".java": "Java", ".kt": "Kotlin",
    ".c": "C", ".h": "C/C++ Header", ".cpp": "C++", ".cs": "C#", ".php": "PHP",
    ".rb": "Ruby", ".swift": "Swift", ".sh": "Shell", ".html": "HTML", ".css": "CSS",
    ".scss": "SCSS", ".vue": "Vue", ".svelte": "Svelte", ".sql": "SQL",
    ".md": "Markdown", ".json": "JSON", ".yml": "YAML", ".yaml": "YAML", ".toml": "TOML",
}
MAX_FILE_BYTES = 1_000_000


# ----------------------------------------------------------------------------
# Dateien einsammeln
# ----------------------------------------------------------------------------
def load_gitignore(root: Path):
    patterns = []
    gi = root / ".gitignore"
    if gi.is_file():
        for line in gi.read_text(errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith(("#", "!")):
                patterns.append(line)
    return patterns


def ignored_by_gitignore(rel: str, patterns) -> bool:
    name = rel.rsplit("/", 1)[-1]
    for p in patterns:
        p2 = p.rstrip("/").lstrip("/")
        if fnmatch.fnmatch(name, p2) or fnmatch.fnmatch(rel, p2) or rel.startswith(p2 + "/"):
            return True
    return False


def is_binary(path: Path) -> bool:
    try:
        with open(path, "rb") as f:
            return b"\0" in f.read(2048)
    except OSError:
        return True


def collect(root: Path, skip_names: set):
    patterns = load_gitignore(root)
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root).replace(os.sep, "/")
        rel_dir = "" if rel_dir == "." else rel_dir
        dirnames[:] = sorted(
            d for d in dirnames
            if d not in IGNORE_DIRS and not d.endswith(".egg-info")
            and not ignored_by_gitignore(f"{rel_dir}/{d}".lstrip("/"), patterns)
        )
        for fn in sorted(filenames):
            rel = f"{rel_dir}/{fn}".lstrip("/")
            if (fn in IGNORE_FILES or fn in skip_names or fn.lower().endswith(".appimage")
                    or ignored_by_gitignore(rel, patterns)):
                continue
            p = Path(dirpath) / fn
            try:
                size = p.stat().st_size
            except OSError:
                continue
            if size > MAX_FILE_BYTES or is_binary(p):
                files.append({"rel": rel, "path": p, "size": size, "lines": 0, "text": False})
                continue
            try:
                lines = p.read_text(errors="ignore").count("\n") + 1
            except OSError:
                lines = 0
            files.append({"rel": rel, "path": p, "size": size, "lines": lines, "text": True})
    return files


# ----------------------------------------------------------------------------
# Baum
# ----------------------------------------------------------------------------
def render_tree(files, max_depth: int, max_entries: int) -> str:
    tree = {}
    for f in files:
        parts = f["rel"].split("/")
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part + "/", {})
        node[parts[-1]] = None

    out = []

    def walk(node, prefix, depth):
        items = sorted(node.items(), key=lambda kv: (kv[1] is None, kv[0].lower()))
        shown = items[:max_entries]
        for i, (name, child) in enumerate(shown):
            last = i == len(shown) - 1 and len(items) <= max_entries
            out.append(f"{prefix}{'`-- ' if last else '|-- '}{name}")
            if child is not None:
                if depth + 1 >= max_depth:
                    out.append(f"{prefix}{'    ' if last else '|   '}`-- {tr('tree_files', n=count_files(child))}")
                else:
                    walk(child, prefix + ("    " if last else "|   "), depth + 1)
        if len(items) > max_entries:
            out.append(f"{prefix}`-- {tr('tree_more', n=len(items) - max_entries)}")

    def count_files(node):
        return sum(1 if v is None else count_files(v) for v in node.values())

    walk(tree, "", 0)
    return "\n".join(out)


# ----------------------------------------------------------------------------
# Config- und Doku-Dateien
# ----------------------------------------------------------------------------
def first_paragraph(text: str, limit=400) -> str:
    for block in re.split(r"\n\s*\n", text):
        b = block.strip()
        if b and not b.startswith(("#", "![", "[![", "<", "---", "===")):
            return re.sub(r"\s+", " ", b)[:limit]
    return ""


def read(path: Path) -> str:
    try:
        return path.read_text(errors="ignore")
    except OSError:
        return ""


def summarize_configs(root: Path) -> list:
    notes = []

    for name in ("README.md", "README.rst", "README.txt", "README"):
        p = root / name
        if p.is_file():
            para = first_paragraph(read(p))
            if para:
                notes.append(f"**{name}:** {para}")
            break

    p = root / "package.json"
    if p.is_file():
        try:
            d = json.loads(read(p))
            notes.append(f"**package.json:** name=`{d.get('name', '?')}`"
                         + (f", {d['description']}" if d.get("description") else ""))
            if d.get("scripts"):
                notes.append("  - Scripts: " + ", ".join(f"`npm run {k}`" for k in list(d["scripts"])[:12]))
            deps = list(d.get("dependencies", {}))
            if deps:
                notes.append("  - Dependencies: " + ", ".join(deps[:25]) + (" ..." if len(deps) > 25 else ""))
        except json.JSONDecodeError:
            pass

    p = root / "pyproject.toml"
    if p.is_file():
        try:
            import tomllib  # Python 3.11+
            d = tomllib.loads(read(p))
            proj = d.get("project", {})
            notes.append(f"**pyproject.toml:** name=`{proj.get('name', '?')}`"
                         + (f", {proj['description']}" if proj.get("description") else ""))
            if proj.get("requires-python"):
                notes.append(f"  - Python: `{proj['requires-python']}`")
            deps = proj.get("dependencies", [])
            if deps:
                notes.append("  - Dependencies: " + ", ".join(deps[:25]))
            if proj.get("scripts"):
                notes.append("  - CLI: " + ", ".join(f"`{k}`" for k in proj["scripts"]))
        except Exception:
            notes.append(tr("present", name="pyproject.toml"))

    p = root / "requirements.txt"
    if p.is_file():
        reqs = [l.strip() for l in read(p).splitlines() if l.strip() and not l.startswith(("#", "-"))]
        notes.append("**requirements.txt:** " + ", ".join(reqs[:30]) + (" ..." if len(reqs) > 30 else ""))

    p = root / "Makefile"
    if p.is_file():
        targets = re.findall(r"^([A-Za-z0-9_.-]+):(?!=)", read(p), re.M)
        targets = [t for t in targets if not t.startswith(".")]
        if targets:
            notes.append("**Makefile-Targets:** " + ", ".join(f"`make {t}`" for t in targets[:15]))

    for name in ("Dockerfile", "docker-compose.yml", "docker-compose.yaml"):
        p = root / name
        if p.is_file():
            txt = read(p)
            froms = re.findall(r"^FROM\s+(\S+)", txt, re.M)
            cmd = re.findall(r"^(?:CMD|ENTRYPOINT)\s+(.+)$", txt, re.M)
            info = f"**{name}:**"
            if froms:
                info += tr("docker_base") + ", ".join(f"`{x}`" for x in froms)
            if cmd:
                info += tr("docker_start", cmd=cmd[-1][:80])
            notes.append(info)

    for name in ("go.mod", "Cargo.toml", "pom.xml", "composer.json", "Gemfile"):
        if (root / name).is_file():
            notes.append(tr("present", name=name))
    return notes


# ----------------------------------------------------------------------------
# Code-Analyse
# ----------------------------------------------------------------------------
def sig_of(fn) -> str:
    try:
        args = ast.unparse(fn.args)
    except Exception:
        args = "..."
    prefix = "async " if isinstance(fn, ast.AsyncFunctionDef) else ""
    ret = ""
    if getattr(fn, "returns", None) is not None:
        try:
            ret = " -> " + ast.unparse(fn.returns)
        except Exception:
            pass
    return f"{prefix}{fn.name}({args}){ret}"


def analyze_python(text: str, max_items: int):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None, [], False
    doc = (ast.get_docstring(tree) or "").strip().split("\n")[0][:160]
    items = []
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            bases = ", ".join(ast.unparse(b) for b in node.bases) if node.bases else ""
            methods = [n.name for n in node.body
                       if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and not n.name.startswith("_")]
            line = f"class {node.name}" + (f"({bases})" if bases else "")
            if methods:
                line += ": " + ", ".join(methods[:8]) + (" ..." if len(methods) > 8 else "")
            items.append(line)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            items.append("def " + sig_of(node))
    is_main = "__name__" in text and "__main__" in text
    return doc, items[:max_items], is_main


JS_RE = re.compile(
    r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function\*?|class|interface|type|enum)\s+([A-Za-z0-9_$]+)"
    r"|^\s*export\s+(?:const|let)\s+([A-Za-z0-9_$]+)", re.M)
GO_RE = re.compile(r"^(?:func\s+(?:\([^)]*\)\s*)?|type\s+)([A-Za-z0-9_]+)", re.M)
RUST_RE = re.compile(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?(?:fn|struct|enum|trait)\s+([A-Za-z0-9_]+)", re.M)
CLASS_RE = re.compile(r"^\s*(?:public\s+|abstract\s+|final\s+|static\s+)*(?:class|interface|enum|record)\s+([A-Za-z0-9_]+)", re.M)

REGEX_BY_EXT = {
    ".js": JS_RE, ".jsx": JS_RE, ".ts": JS_RE, ".tsx": JS_RE,
    ".go": GO_RE, ".rs": RUST_RE,
    ".java": CLASS_RE, ".kt": CLASS_RE, ".cs": CLASS_RE,
}


def analyze_other(text: str, ext: str, max_items: int):
    rx = REGEX_BY_EXT.get(ext)
    if not rx:
        return []
    names = []
    for m in rx.finditer(text):
        n = next((g for g in m.groups() if g), None)
        if n and n not in names:
            names.append(n)
    return names[:max_items]


ENTRY_NAMES = {"main.py", "app.py", "manage.py", "wsgi.py", "asgi.py", "__main__.py", "cli.py",
               "index.js", "index.ts", "main.js", "main.ts", "server.js", "server.ts",
               "app.js", "app.ts", "main.go", "main.rs", "Main.java", "Program.cs"}


NON_CODE_EXT = {".md", ".json", ".yml", ".yaml", ".toml", ".html", ".css", ".scss", ".sql"}


def summarize_code(files, max_files: int, max_items: int):
    lines_out, entries = [], []
    count = 0
    total_code = 0
    for f in files:
        if not f["text"]:
            continue
        ext = Path(f["rel"]).suffix.lower()
        if ext not in LANGS or ext in NON_CODE_EXT:
            continue
        total_code += 1
        if Path(f["rel"]).name in ENTRY_NAMES:
            entries.append(f["rel"])
        if count >= max_files:
            continue
        text = read(f["path"])
        doc, items, is_main = "", [], False
        if ext == ".py":
            doc, items, is_main = analyze_python(text, max_items)
            doc = doc or ""
            if is_main and f["rel"] not in entries:
                entries.append(f["rel"])
        else:
            items = analyze_other(text, ext, max_items)
        if not (doc or items):
            continue
        count += 1
        head = f"- `{f['rel']}` {tr('file_lines', n=f['lines'])}"
        if doc:
            head += f" - {doc}"
        lines_out.append(head)
        for it in items:
            lines_out.append(f"    - {it}")
    skipped = max(0, total_code - count)
    return lines_out, entries, skipped


# ----------------------------------------------------------------------------
# Optional: LLM (OpenAI-kompatible API, z. B. Ollama, LM Studio, llama.cpp-server)
# ----------------------------------------------------------------------------
def ask_llm(prompt: str, base_url: str, model: str, api_key: str) -> str:
    payload = json.dumps({
        "model": model,
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content":
             tr("llm_system")},
            {"role": "user", "content": prompt},
        ],
    }).encode()
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions", data=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"})
    with urllib.request.urlopen(req, timeout=900) as r:
        content = json.load(r)["choices"][0]["message"]["content"]
    return re.sub(r"<think>.*?</think>", "", content, flags=re.S).strip()


def build_summary(root: Path, skip_names=None, max_depth: int = 4, max_entries: int = 25,
                  max_files: int = 80, max_items: int = 12, lang=None) -> str:
    """Erzeugt die Markdown-Zusammenfassung für einen Ordner und gibt sie als Text zurück."""
    if lang:
        set_lang(lang)
    root = Path(root)
    skip = set(skip_names or ())
    files = collect(root, skip)
    if not files:
        raise ValueError(tr("no_files"))

    # Statistik
    lang_lines, lang_files = Counter(), Counter()
    for f in files:
        lang = LANGS.get(Path(f["rel"]).suffix.lower())
        if lang and f["text"]:
            lang_lines[lang] += f["lines"]
            lang_files[lang] += 1
    total_lines = sum(f["lines"] for f in files)

    parts = [tr("title", name=root.name), ""]
    lines_fmt = f"{total_lines:,}".replace(",", ".")
    parts.append(tr("generated", files=len(files), lines=lines_fmt))
    parts.append("")

    if lang_files:
        parts.append("## " + tr("h_langs"))
        for lang, n in lang_lines.most_common(8):
            parts.append(tr("lang_row", lang=lang, files=lang_files[lang], fw=plural("w_file", lang_files[lang]),
                            lines=n, lw=plural("w_line", n)))
        parts.append("")

    notes = summarize_configs(root)
    if notes:
        parts.append("## " + tr("h_info"))
        parts.extend(f"- {n}" if not n.startswith("  ") else n for n in notes)
        parts.append("")

    parts += ["## " + tr("h_struct"), "```", f"{root.name}/", render_tree(files, max_depth, max_entries), "```", ""]

    code_lines, entries, skipped = summarize_code(files, max_files, max_items)
    if entries:
        parts.append("## " + tr("h_entry"))
        parts.extend(f"- `{e}`" for e in entries[:10])
        parts.append("")
    if code_lines:
        parts.append("## " + tr("h_modules"))
        parts.extend(code_lines)
        if skipped:
            parts.append(tr("skipped", n=skipped))
        parts.append("")

    structural = "\n".join(parts)
    return structural


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    set_lang(lang_from_argv(sys.argv[1:]))
    ap = argparse.ArgumentParser(description=tr("p_desc"))
    ap.add_argument("path", nargs="?", default=".", help=tr("p_path"))
    ap.add_argument("-o", "--output", default="PROJECT_SUMMARY.md", help=tr("p_out"))
    ap.add_argument("--max-depth", type=int, default=4, help=tr("p_depth"))
    ap.add_argument("--max-entries", type=int, default=25, help=tr("p_entries"))
    ap.add_argument("--max-files", type=int, default=80, help=tr("p_files"))
    ap.add_argument("--max-items", type=int, default=12, help=tr("p_items"))
    ap.add_argument("--stdout", action="store_true", help=tr("p_stdout"))
    ap.add_argument("--lang", choices=["auto", "de", "en"], default="auto", help=tr("p_lang"))
    g = ap.add_argument_group("LLM")
    g.add_argument("--llm", action="store_true", help=tr("p_llm"))
    g.add_argument("--base-url", default=os.environ.get("OPENAI_BASE_URL", "http://localhost:11434/v1"))
    g.add_argument("--model", default=os.environ.get("LLM_MODEL", "qwen3.6:35b-a3b"))
    g.add_argument("--api-key", default=os.environ.get("OPENAI_API_KEY", "none"))
    args = ap.parse_args()
    set_lang(None if args.lang == "auto" else args.lang)

    root = Path(args.path).expanduser().resolve()
    if not root.is_dir():
        sys.exit(tr("not_dir", p=root))

    out_path = Path(args.output)
    if not out_path.is_absolute():
        out_path = root / out_path
    skip = {out_path.name} if out_path.parent == root else set()

    try:
        structural = build_summary(root, skip, args.max_depth, args.max_entries, args.max_files, args.max_items)
    except ValueError as e:
        sys.exit(str(e))

    if args.llm:
        print(tr("llm_ask"), file=sys.stderr)
        prompt = tr("llm_prompt") + structural[:24000]
        try:
            intro = ask_llm(prompt, args.base_url, args.model, args.api_key)
            structural = structural.replace("\n## ", f"\n## {tr('h_llm')}\n{intro}\n\n## ", 1)
        except Exception as e:  # noqa: BLE001
            print(tr("llm_fail", e=e), file=sys.stderr)

    if args.stdout:
        print(structural)
    else:
        out_path.write_text(structural + "\n", encoding="utf-8")
        print(tr("written", path=out_path, chars=len(structural), tokens=len(structural) // 4))


if __name__ == "__main__":
    main()

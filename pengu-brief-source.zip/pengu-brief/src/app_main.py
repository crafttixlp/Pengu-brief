#!/usr/bin/env python3
"""
Pengu-Brief - entry point with several modes / Einstiegspunkt mit mehreren Modi:

    (no arguments)          start the GUI
    <folder> [options]      command line (e.g. --stdout, -o FILE, --lang de|en)
    --mcp                   MCP server over stdio (for AI coding agents)
    --init-agent [FOLDER]   write instructions for agents into AGENTS.md + print MCP config
    --mcp-config            print the MCP configuration only
    --gui                   force the GUI
"""
import json
import os
import sys
from pathlib import Path

import summarize_folder
from agent_setup import APP_NAME, APP_TITLE, VERSION, init_agent_cli, mcp_config_json
from i18n import detect_lang, lang_from_argv

USAGE = {
    "de": f"""{APP_TITLE} {VERSION}

Modi:
  (ohne Argumente)         GUI starten
  <ordner> [Optionen]      Zusammenfassung erzeugen (CLI), z. B. '. --stdout' oder '. -o CLAUDE.md'
  --mcp                    MCP-Server über stdio starten (für KI-Coding-Agenten)
  --init-agent [ORDNER]    Block in AGENTS.md schreiben (--file NAME für andere Datei) und MCP-Config zeigen
  --mcp-config             MCP-Konfiguration als JSON ausgeben
  --gui                    GUI erzwingen
  --version                Version anzeigen
  --lang de|en             Sprache (Standard: nach System-Sprache)

Optionen der Kommandozeile:
""",
    "en": f"""{APP_TITLE} {VERSION}

Modes:
  (no arguments)           start the GUI
  <folder> [options]       create a summary (CLI), e.g. '. --stdout' or '. -o CLAUDE.md'
  --mcp                    start the MCP server over stdio (for AI coding agents)
  --init-agent [FOLDER]    write a block into AGENTS.md (--file NAME for another file) and show the MCP config
  --mcp-config             print the MCP configuration as JSON
  --gui                    force the GUI
  --version                show the version
  --lang de|en             language (default: from the system language)

Command line options:
""",
}
NO_DISPLAY = {
    "de": "Kein Display gefunden, daher keine GUI. Beispiel: --stdout .\n",
    "en": "No display found, so no GUI. Example: --stdout .\n",
}


# ----------------------------------------------------------------------------
# MCP server (JSON-RPC 2.0 over stdio, one message per line)
# ----------------------------------------------------------------------------
TOOL = {
    "name": "summarize_folder",
    "description": (
        "Summarizes a project folder compactly: languages, dependencies, directory tree, entry points "
        "and classes/functions per file (no source code). Use it at the start of a task to understand "
        "the project quickly instead of reading many files."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Project folder (default: current directory)."},
            "max_depth": {"type": "integer", "description": "Depth of the directory tree (default 4)."},
            "max_files": {"type": "integer", "description": "Max. code files with details (default 80)."},
            "max_chars": {"type": "integer", "description": "Truncate the answer after this many characters (default 40000)."},
            "lang": {"type": "string", "enum": ["de", "en"],
                     "description": "Language of the headings in the result (default: automatic)."},
            "output_file": {
                "type": "string",
                "description": "Optional: additionally write the result to this .md/.txt file "
                               "(a relative path is resolved from the project folder).",
            },
        },
    },
}


def run_tool(args: dict) -> str:
    lang = summarize_folder.set_lang(args.get("lang"))
    root = Path(args.get("path") or ".").expanduser().resolve()
    if not root.is_dir():
        raise ValueError(summarize_folder.tr("not_dir", p=root))
    out_file = None
    skip = set()
    if args.get("output_file"):
        out_file = Path(args["output_file"]).expanduser()
        if not out_file.is_absolute():
            out_file = root / out_file
        if out_file.suffix.lower() not in (".md", ".txt"):
            raise ValueError("output_file must end in .md or .txt")
        if out_file.parent == root:
            skip.add(out_file.name)
    text = summarize_folder.build_summary(
        root, skip,
        max_depth=int(args.get("max_depth") or 4),
        max_files=int(args.get("max_files") or 80),
        lang=lang,
    )
    note = ""
    if out_file is not None:
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(text + "\n", encoding="utf-8")
        note = f"\n\n(Saved to {out_file})"
    limit = int(args.get("max_chars") or 40000)
    if len(text) > limit:
        text = text[:limit] + f"\n\n[... truncated to {limit} characters; lower max_files/max_depth or raise max_chars]"
    return text + note


def serve_mcp() -> int:
    out = sys.stdout
    try:
        out.reconfigure(encoding="utf-8")
        sys.stdin.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    sys.stdout = sys.stderr  # stray print() output must not disturb the protocol

    def send(obj):
        out.write(json.dumps(obj, ensure_ascii=False) + "\n")
        out.flush()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            continue
        if not isinstance(msg, dict):
            continue
        method, mid, params = msg.get("method"), msg.get("id"), msg.get("params") or {}
        if mid is None:  # notification (e.g. notifications/initialized): no reply
            continue
        if method == "initialize":
            send({"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": params.get("protocolVersion") or "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": APP_NAME, "version": VERSION},
                "instructions": "Call summarize_folder to get a compact overview of a project folder.",
            }})
        elif method == "ping":
            send({"jsonrpc": "2.0", "id": mid, "result": {}})
        elif method == "tools/list":
            send({"jsonrpc": "2.0", "id": mid, "result": {"tools": [TOOL]}})
        elif method == "tools/call":
            if params.get("name") != TOOL["name"]:
                send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": f"Unknown tool: {params.get('name')}"}})
                continue
            try:
                text, is_err = run_tool(params.get("arguments") or {}), False
            except Exception as e:  # noqa: BLE001
                text, is_err = f"Error: {e}", True
            send({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": text}], "isError": is_err}})
        else:
            send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Method not found: {method}"}})
    return 0


# ----------------------------------------------------------------------------
# Entry
# ----------------------------------------------------------------------------
def has_display() -> bool:
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def start_gui() -> int:
    import pengu_gui  # noqa: WPS433 (imported late so that CLI/MCP run without Tk)
    pengu_gui.main()
    return 0


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    args = sys.argv[1:]
    lang = detect_lang(lang_from_argv(args))
    if not args:
        if has_display():
            return start_gui()
        print(USAGE[lang])
        print(NO_DISPLAY[lang])
        return 2
    first = args[0]
    if first == "--gui":
        return start_gui()
    if first == "--mcp":
        return serve_mcp()
    if first == "--mcp-config":
        print(mcp_config_json())
        return 0
    if first == "--init-agent":
        return init_agent_cli(args[1:])
    if first in ("-V", "--version"):
        print(VERSION)
        return 0
    if first in ("-h", "--help"):
        print(USAGE[lang])
    # everything else: the normal command line of summarize_folder
    sys.argv = [APP_NAME] + args
    summarize_folder.main()
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except BrokenPipeError:  # e.g. output piped into `head`
        try:
            sys.stdout.close()
        except Exception:  # noqa: BLE001
            pass
        code = 0
    sys.exit(code)

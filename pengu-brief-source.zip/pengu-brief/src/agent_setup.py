"""Pengu-Brief - Anbindung an KI-Coding-Agenten (AGENTS.md-Block, MCP-Konfiguration) / agent integration."""
import json
import os
import shlex
import sys
from pathlib import Path

from i18n import detect_lang, lang_from_argv

APP_NAME = "pengu-brief"
APP_TITLE = "Pengu-Brief"
VERSION = "2.1.0"
MARK_START = "<!-- pengu-brief:start -->"
MARK_END = "<!-- pengu-brief:end -->"
AGENT_FILES = ["AGENTS.md", "CLAUDE.md", "GEMINI.md", ".cursorrules"]

MSG = {
    "de": {"created": "angelegt", "appended": "ergänzt", "updated": "aktualisiert",
           "not_dir": "Kein Ordner: {p}", "bad_name": "Der Dateiname darf keinen Pfad enthalten.",
           "bad_file_arg": "--file erwartet nur einen Dateinamen, keinen Pfad.",
           "mcp_hint": "Für Agenten mit MCP-Unterstützung (z. B. Claude Code `.mcp.json`, Cursor `mcp.json`):"},
    "en": {"created": "created", "appended": "extended", "updated": "updated",
           "not_dir": "Not a folder: {p}", "bad_name": "The file name must not contain a path.",
           "bad_file_arg": "--file expects a file name only, not a path.",
           "mcp_hint": "For agents with MCP support (e.g. Claude Code `.mcp.json`, Cursor `mcp.json`):"},
}


def self_path() -> str:
    """Pfad zum AppImage (vom AppImage-Runtime gesetzt) bzw. zur Binary/zum Skript."""
    if os.environ.get("APPIMAGE"):
        return os.environ["APPIMAGE"]
    if getattr(sys, "frozen", False):
        return sys.executable
    return os.path.abspath(sys.argv[0])


def display_path(target: Path) -> str:
    """Pfad für die Anleitung: relativ zum Projektordner, wenn das Programm darin liegt."""
    me = Path(self_path()).resolve()
    try:
        return "./" + str(me.relative_to(target.resolve()))
    except ValueError:
        return str(me)


def mcp_config() -> dict:
    return {
        "mcpServers": {
            APP_NAME: {
                "command": str(Path(self_path()).resolve()),
                "args": ["--mcp"],
                "env": {"APPIMAGE_EXTRACT_AND_RUN": "1"},
            }
        }
    }


def mcp_config_json() -> str:
    return json.dumps(mcp_config(), indent=2)


def agent_block(target: Path, lang=None) -> str:
    lang = detect_lang(lang)
    tool = display_path(target)
    cmd = f"APPIMAGE_EXTRACT_AND_RUN=1 {shlex.quote(tool)}"
    if lang == "de":
        body = f"""## Projektübersicht ({APP_TITLE})

In diesem Projekt liegt das Werkzeug `{tool}`. Es erzeugt eine kompakte Übersicht
(Struktur, Einstiegspunkte, Klassen/Funktionen, Abhängigkeiten), damit nicht jede Datei einzeln
gelesen werden muss.

- Übersicht ausgeben: `{cmd} . --stdout --lang de`
- Als Datei speichern: `{cmd} . -o PROJECT_SUMMARY.md --lang de`
- Ist ein MCP-Server mit dem Namen `{APP_NAME}` eingerichtet, nutze stattdessen das Tool `summarize_folder`.

Regeln: Lies zuerst diese Übersicht, bevor du viele Dateien oeffnest. Erzeuge sie neu, wenn sich die
Projektstruktur deutlich geändert hat. Die Übersicht zeigt nur Signaturen und Namen, keinen Code:
für Details die betreffende Datei lesen.
"""
    else:
        body = f"""## Project overview ({APP_TITLE})

This project contains the tool `{tool}`. It generates a compact overview
(structure, entry points, classes/functions, dependencies) so that not every file has to be read
individually.

- Print the overview: `{cmd} . --stdout --lang en`
- Save it as a file: `{cmd} . -o PROJECT_SUMMARY.md --lang en`
- If an MCP server named `{APP_NAME}` is set up, use the `summarize_folder` tool instead.

Rules: Read this overview first, before you open many files. Regenerate it when the project structure
has changed significantly. The overview only shows names and signatures, no code: read the relevant
file for details.
"""
    return f"{MARK_START}\n{body}{MARK_END}\n"


def write_agent_block(folder, filename: str = "AGENTS.md", lang=None) -> tuple:
    """Schreibt/aktualisiert den Block. Gibt (Pfad, 'created'|'appended'|'updated') zurück."""
    lang = detect_lang(lang)
    m = MSG[lang]
    target = Path(folder).expanduser().resolve()
    if not target.is_dir():
        raise ValueError(m["not_dir"].format(p=target))
    if not filename or "/" in filename or "\\" in filename or filename in (".", ".."):
        raise ValueError(m["bad_name"])
    path = target / filename
    block = agent_block(target, lang)
    old = path.read_text(encoding="utf-8") if path.exists() else ""
    if MARK_START in old and MARK_END in old:
        a = old.index(MARK_START)
        b = old.index(MARK_END) + len(MARK_END)
        new = old[:a] + block.rstrip("\n") + old[b:]
        action = "updated"
    else:
        new = (old.rstrip("\n") + "\n\n" if old.strip() else "") + block
        action = "appended" if old.strip() else "created"
    path.write_text(new if new.endswith("\n") else new + "\n", encoding="utf-8")
    return path, action


def init_agent_cli(argv) -> int:
    lang = detect_lang(lang_from_argv(list(argv)))
    m = MSG[lang]
    folder, filename = ".", "AGENTS.md"
    rest = list(argv)
    while rest:
        a = rest.pop(0)
        if a == "--file" and rest:
            filename = rest.pop(0)
        elif a == "--lang" and rest:
            rest.pop(0)
        elif a.startswith("--lang="):
            continue
        else:
            folder = a
    try:
        path, action = write_agent_block(folder, filename, lang)
    except ValueError as e:
        print(e, file=sys.stderr)
        return 2
    print(f"{path} {m[action]}.\n")
    print(m["mcp_hint"])
    print(mcp_config_json())
    return 0

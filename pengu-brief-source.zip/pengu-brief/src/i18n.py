"""Pengu-Brief - Sprachwahl (de/en)."""
import os

SUPPORTED = ("de", "en")


def detect_lang(explicit=None) -> str:
    """Sprache bestimmen: explizite Angabe > PENGU_LANG > System-Locale. Sonst Englisch."""
    cand = (explicit or "").strip().lower()
    if cand in SUPPORTED:
        return cand
    env = os.environ.get("PENGU_LANG", "").strip().lower()
    if env[:2] in SUPPORTED:
        return env[:2]
    for var in ("LC_ALL", "LC_MESSAGES", "LANGUAGE", "LANG"):
        val = os.environ.get(var, "").strip().lower()
        if val:
            return "de" if val.startswith("de") else "en"
    return "en"


def lang_from_argv(argv):
    """Liest --lang aus einer Argumentliste (ohne sie zu veraendern)."""
    for i, a in enumerate(argv):
        if a == "--lang" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--lang="):
            return a.split("=", 1)[1]
    return None

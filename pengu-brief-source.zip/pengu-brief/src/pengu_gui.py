#!/usr/bin/env python3
"""Pengu-Brief - modern GUI (CustomTkinter), German/English."""
import contextlib
import io
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk
from PIL import Image, ImageDraw

import agent_setup
import summarize_folder
from agent_setup import AGENT_FILES, APP_TITLE
from i18n import detect_lang

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "pengu-brief"
CONFIG_FILE = CONFIG_DIR / "config.json"

ACCENT = ("#0891b2", "#22b8cf")
ACCENT_HOVER = ("#0e7490", "#4fd1e5")
ACCENT_TEXT = ("#ffffff", "#06202a")
TEXT = ("#0f172a", "#e2e8f0")
TAB_SEL = ("#67e8f9", "#0e7490")
TAB_SEL_HOVER = ("#22d3ee", "#0891b2")
CARD = ("#eef2f6", "#1b2432")
BG = ("#f6f8fb", "#111823")
MUTED = ("#5b6b7d", "#8b9bb0")
OK = ("#15803d", "#4ade80")
ERR = ("#b91c1c", "#f87171")
SECONDARY = ("#dbe3ec", "#2b384b")
SECONDARY_HOVER = ("#c9d4e0", "#35455c")

LANG_NAMES = {"de": "Deutsch", "en": "English"}
OLD_MODE_LABELS = {"Dunkel": "dark", "Hell": "light", "Auto": "system"}

STR = {
    "sub": ("Projekte auf das Wesentliche eindampfen – für dich und deine KI-Agenten",
            "Boil projects down to the essentials – for you and your AI agents"),
    "tab_run": ("Zusammenfassen", "Summarize"),
    "tab_prev": ("Vorschau", "Preview"),
    "tab_agent": ("KI-Agent", "AI agent"),
    "mode_dark": ("Dunkel", "Dark"), "mode_light": ("Hell", "Light"), "mode_auto": ("Auto", "Auto"),
    "card_src": ("Quelle und Ziel", "Source and target"),
    "lbl_project": ("Projektordner", "Project folder"),
    "ph_project": ("Ordner, der zusammengefasst werden soll", "Folder to summarize"),
    "lbl_outdir": ("Ausgabeordner", "Output folder"),
    "ph_outdir": ("leer = Projektordner", "empty = project folder"),
    "btn_choose": ("Wählen", "Choose"),
    "lbl_filename": ("Dateiname", "File name"),
    "card_detail": ("Detailgrad", "Level of detail"),
    "lbl_depth": ("Baumtiefe", "Tree depth"),
    "lbl_files": ("Code-Dateien", "Code files"),
    "sw_llm": ("Einleitung mit lokalem LLM schreiben lassen (Ollama, LM Studio ...)",
               "Write an introduction with a local LLM (Ollama, LM Studio ...)"),
    "lbl_url": ("API-URL", "API URL"),
    "lbl_model": ("Modell", "Model"),
    "btn_run": ("Zusammenfassen", "Summarize"),
    "btn_running": ("Arbeite ...", "Working ..."),
    "st_ready": ("Bereit.", "Ready."),
    "st_working": ("Fasse zusammen ...", "Summarizing ..."),
    "st_done": ("Fertig: {path}", "Done: {path}"),
    "err_folder": ("Bitte einen gültigen Projektordner wählen.", "Please choose a valid project folder."),
    "err_name": ("Der Dateiname darf keinen Pfad enthalten.", "The file name must not contain a path."),
    "err_outdir": ("Ausgabeordner nicht nutzbar: {e}", "Output folder not usable: {e}"),
    "err_read": ("Datei konnte nicht gelesen werden: {e}", "Could not read the file: {e}"),
    "err_generic": ("Es ist ein Fehler aufgetreten.", "An error occurred."),
    "confirm": ("{path}\nexistiert schon. Soll die Datei überschrieben werden?",
                "{path}\nalready exists. Do you want to overwrite it?"),
    "btn_cancel": ("Abbrechen", "Cancel"),
    "btn_overwrite": ("Überschreiben", "Overwrite"),
    "prev_empty": ("Noch nichts erzeugt. Wähle einen Ordner und klicke auf „Zusammenfassen“.",
                   "Nothing generated yet. Choose a folder and click “Summarize”."),
    "btn_copy": ("Kopieren", "Copy"),
    "btn_openout": ("Ausgabeordner öffnen", "Open output folder"),
    "prev_info": ("{lines} Zeilen  |  ca. {tokens} Tokens", "{lines} lines  |  approx. {tokens} tokens"),
    "copied_prev": ("Vorschau kopiert.", "Preview copied."),
    "copied_mcp": ("MCP-Konfiguration kopiert.", "MCP configuration copied."),
    "agent_intro": (
        "So nutzt ein KI-Coding-Agent Pengu-Brief: Lege die AppImage-Datei in deinen Projektordner und schreibe "
        "die Anleitung in die Datei, die dein Agent beim Start liest. Mit MCP kann der Agent das Werkzeug "
        "zusätzlich direkt aufrufen.",
        "How an AI coding agent uses Pengu-Brief: put the AppImage file into your project folder and write the "
        "instructions into the file your agent reads on startup. With MCP the agent can also call the tool directly."),
    "card_agent1": ("1  Anleitung für den Agenten schreiben", "1  Write instructions for the agent"),
    "ph_agent_dir": ("Projekt, in dem der Agent arbeitet", "Project the agent works in"),
    "lbl_agent_file": ("Datei", "File"),
    "btn_write": ("In Projekt schreiben", "Write to project"),
    "agent_hint": ("Vorhandener Text in der Datei bleibt erhalten, nur der Pengu-Brief-Block wird ergänzt.",
                   "Existing text in the file is kept; only the Pengu-Brief block is added."),
    "agent_choose": ("Bitte zuerst den Projektordner wählen.", "Please choose the project folder first."),
    "agent_done": ("{name} {action}: {path}", "{name} {action}: {path}"),
    "card_agent2": ("2  MCP-Server einrichten (optional)", "2  Set up the MCP server (optional)"),
    "mcp_hint": ("In .mcp.json (Claude Code) oder mcp.json (Cursor) einfügen:",
                 "Paste into .mcp.json (Claude Code) or mcp.json (Cursor):"),
    "btn_copy_mcp": ("Konfiguration kopieren", "Copy configuration"),
    "dlg_project": ("Projektordner wählen", "Choose project folder"),
    "dlg_out": ("Ausgabeordner wählen", "Choose output folder"),
    "dlg_agent": ("Projektordner des Agenten wählen", "Choose the agent's project folder"),
}


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def resource(name: str) -> Path:
    """Finds bundled files: next to the program (AppImage) or in ../assets (source tree)."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    for cand in (base / name, base / "assets" / name, base.parent / "assets" / name):
        if cand.exists():
            return cand
    return base / name


def load_config() -> dict:
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def save_config(cfg: dict) -> None:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except OSError:
        pass


def clean_env() -> dict:
    """Environment for external programs: drop the library paths set by PyInstaller."""
    env = dict(os.environ)
    if "LD_LIBRARY_PATH_ORIG" in env:
        env["LD_LIBRARY_PATH"] = env["LD_LIBRARY_PATH_ORIG"]
    else:
        env.pop("LD_LIBRARY_PATH", None)
    return env


def pick_dir(title: str, initial: str) -> str:
    """Folder dialog: prefers the desktop's own dialog (zenity/kdialog), falls back to Tk."""
    start = initial if initial and Path(initial).is_dir() else str(Path.home())
    try:
        if shutil.which("zenity"):
            r = subprocess.run(["zenity", "--file-selection", "--directory", f"--title={title}",
                                f"--filename={start.rstrip('/')}/"],
                               capture_output=True, text=True, env=clean_env(), timeout=3600)
            return r.stdout.strip() if r.returncode == 0 else ""
        if shutil.which("kdialog"):
            r = subprocess.run(["kdialog", "--getexistingdirectory", start, "--title", title],
                               capture_output=True, text=True, env=clean_env(), timeout=3600)
            return r.stdout.strip() if r.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        pass
    return filedialog.askdirectory(title=title, initialdir=start) or ""


def open_folder(path: Path) -> bool:
    try:
        subprocess.Popen(["xdg-open", str(path)], env=clean_env(),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except OSError:
        return False


def make_flag(code: str, w: int = 36, h: int = 24) -> Image.Image:
    """Zeichnet eine kleine Flagge (de = Deutschland, en = Vereinigtes Koenigreich)."""
    S = 10
    W, H = w * S, h * S
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if code == "de":
        d.rectangle([0, 0, W, H / 3], fill="#000000")
        d.rectangle([0, H / 3, W, 2 * H / 3], fill="#DD0000")
        d.rectangle([0, 2 * H / 3, W, H], fill="#FFCE00")
    else:
        blue, white, red = "#012169", "#FFFFFF", "#C8102E"
        d.rectangle([0, 0, W, H], fill=blue)
        for (x0, y0, x1, y1) in ((0, 0, W, H), (0, H, W, 0)):
            d.line([x0, y0, x1, y1], fill=white, width=int(H * 0.22))
            d.line([x0, y0, x1, y1], fill=red, width=int(H * 0.08))
        d.rectangle([0, H * 0.5 - H * 0.17, W, H * 0.5 + H * 0.17], fill=white)
        d.rectangle([W * 0.5 - W * 0.085, 0, W * 0.5 + W * 0.085, H], fill=white)
        d.rectangle([0, H * 0.5 - H * 0.10, W, H * 0.5 + H * 0.10], fill=red)
        d.rectangle([W * 0.5 - W * 0.05, 0, W * 0.5 + W * 0.05, H], fill=red)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, H - 1], radius=3 * S, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    ImageDraw.Draw(out).rounded_rectangle([0, 0, W - 1, H - 1], radius=3 * S, outline=(0, 0, 0, 70), width=S // 2)
    return out


class QueueWriter(io.TextIOBase):
    def __init__(self, q):
        self.q = q

    def write(self, s: str) -> int:
        if s:
            self.q.put(("log", s))
        return len(s)


# ----------------------------------------------------------------------------
# App
# ----------------------------------------------------------------------------
class App(ctk.CTk):
    def __init__(self):
        self.cfg = load_config()
        self.mode = self.cfg.get("mode") or OLD_MODE_LABELS.get(self.cfg.get("mode_label", ""), "dark")
        if self.mode not in ("dark", "light", "system"):
            self.mode = "dark"
        self.lang = detect_lang(self.cfg.get("lang"))
        ctk.set_appearance_mode(self.mode)
        ctk.set_default_color_theme("blue")
        super().__init__(fg_color=BG)
        self.title(APP_TITLE)
        self.geometry("800x760")
        self.minsize(720, 680)

        self.q = queue.Queue()
        self.last_output = None
        self.running = False
        self.preview_text = None
        self.preview_info = None
        self.result_ready = False
        self._st = ("st_ready", None, None, {})
        self._agent_st = ("agent_hint", None, None, {})
        self.flags = {c: ctk.CTkImage(make_flag(c), size=(30, 20)) for c in LANG_NAMES}

        c = self.cfg
        self.var_in = tk.StringVar(value=c.get("input", ""))
        self.var_out = tk.StringVar(value=c.get("output", ""))
        self.var_name = tk.StringVar(value=c.get("name", "PROJECT_SUMMARY.md"))
        self.var_depth = tk.IntVar(value=c.get("depth", 4))
        self.var_files = tk.IntVar(value=c.get("files", 80))
        self.var_llm = tk.BooleanVar(value=c.get("llm", False))
        self.var_url = tk.StringVar(value=c.get("url", "http://localhost:11434/v1"))
        self.var_model = tk.StringVar(value=c.get("model", "qwen3.6:35b-a3b"))
        self.var_agent_dir = tk.StringVar(value=c.get("agent_dir", c.get("input", "")))
        self.var_agent_file = tk.StringVar(value=c.get("agent_file", "AGENTS.md"))

        self._set_icon()
        self._build_ui()
        self.after(100, self._poll)
        self.protocol("WM_DELETE_WINDOW", self._close)

    # ------------------------------------------------------------ language
    def t(self, key: str, **kw) -> str:
        de, en = STR[key]
        return (de if self.lang == "de" else en).format(**kw) if kw else (de if self.lang == "de" else en)

    def _toggle_lang(self):
        self.lang = "en" if self.lang == "de" else "de"
        self.cfg["lang"] = self.lang
        save_config(self.cfg)
        self._rebuild()

    def _rebuild(self):
        """Baut die Oberflaeche in der neuen Sprache neu auf; Eingaben und Ergebnis bleiben erhalten."""
        old_names = list(self._tab_names) if hasattr(self, "_tab_names") else []
        try:
            idx = old_names.index(self.tabs.get())
        except (ValueError, AttributeError):
            idx = 0
        self.header.destroy()
        self.tabs.destroy()
        self._build_ui()
        self.tabs.set(self._tab_names[idx])
        self.update_idletasks()

    # ------------------------------------------------------------ layout
    def _set_icon(self):
        self._icon_img = None
        try:
            self._icon_img = Image.open(resource("pengu-brief.png")).convert("RGBA")
        except Exception as e:  # noqa: BLE001
            print(f"Logo could not be loaded: {e}", file=sys.stderr)
            return
        try:  # window icon may fail without hiding the header logo
            from PIL import ImageTk
            self._win_icon = ImageTk.PhotoImage(self._icon_img.resize((128, 128)))
            self.iconphoto(True, self._win_icon)
        except Exception as e:  # noqa: BLE001
            print(f"Window icon not set: {e}", file=sys.stderr)

    def _build_ui(self):
        self._build_header()
        self._build_tabs()
        self._toggle_llm()
        self._update_labels()
        self._render_status()
        self._render_agent_status()
        if self.running:
            self.btn_run.configure(state="disabled", text=self.t("btn_running"))
            self.progress.configure(mode="indeterminate")
            self.progress.start()
        if self.result_ready:
            self.btn_open.configure(state="normal")
            self.btn_copy.configure(state="normal")

    def _build_header(self):
        self.header = ctk.CTkFrame(self, fg_color="transparent")
        bar = self.header
        bar.pack(fill="x", padx=22, pady=(18, 4))
        bar.columnconfigure(1, weight=1)
        if self._icon_img is not None:
            logo = ctk.CTkImage(self._icon_img, size=(54, 54))
            ctk.CTkLabel(bar, image=logo, text="").grid(row=0, column=0, rowspan=2, padx=(0, 14))
        ctk.CTkLabel(bar, text=APP_TITLE, font=ctk.CTkFont(size=26, weight="bold")).grid(row=0, column=1, sticky="sw")
        ctk.CTkLabel(bar, text=self.t("sub"), text_color=MUTED).grid(row=1, column=1, sticky="nw")

        right = ctk.CTkFrame(bar, fg_color="transparent")
        right.grid(row=0, column=2, rowspan=2, sticky="e")
        self.btn_lang = ctk.CTkButton(
            right, text=LANG_NAMES[self.lang], image=self.flags[self.lang], compound="left", width=118, height=30,
            corner_radius=10, fg_color=CARD, hover_color=SECONDARY_HOVER, text_color=TEXT,
            border_width=1, border_color=SECONDARY, command=self._toggle_lang)
        self.btn_lang.grid(row=0, column=0, padx=(0, 10))

        self._mode_labels = {self.t("mode_dark"): "dark", self.t("mode_light"): "light", self.t("mode_auto"): "system"}
        self.seg_mode = ctk.CTkSegmentedButton(
            right, values=list(self._mode_labels), command=self._on_mode, width=170,
            selected_color=TAB_SEL, selected_hover_color=TAB_SEL_HOVER, text_color=TEXT,
            unselected_color=CARD, unselected_hover_color=SECONDARY)
        self.seg_mode.set({v: k for k, v in self._mode_labels.items()}[self.mode])
        self.seg_mode.grid(row=0, column=1)

    def _card(self, parent, title=None, row=0, pady=(0, 12)):
        f = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=14)
        f.grid(row=row, column=0, sticky="ew", pady=pady)
        f.columnconfigure(1, weight=1)
        if title:
            ctk.CTkLabel(f, text=title, font=ctk.CTkFont(size=14, weight="bold")).grid(
                row=0, column=0, columnspan=3, sticky="w", padx=16, pady=(12, 4))
        return f

    def _button(self, parent, text, command, primary=False, width=110, **kw):
        if primary:
            return ctk.CTkButton(parent, text=text, command=command, fg_color=ACCENT, hover_color=ACCENT_HOVER,
                                 text_color=ACCENT_TEXT, corner_radius=10, width=width,
                                 font=ctk.CTkFont(size=14, weight="bold"), **kw)
        return ctk.CTkButton(parent, text=text, command=command, fg_color=SECONDARY, hover_color=SECONDARY_HOVER,
                             text_color=TEXT, corner_radius=10, width=width, **kw)

    def _build_tabs(self):
        self._tab_names = [self.t("tab_run"), self.t("tab_prev"), self.t("tab_agent")]
        self.tabs = ctk.CTkTabview(self, fg_color="transparent", segmented_button_selected_color=TAB_SEL,
                                   segmented_button_selected_hover_color=TAB_SEL_HOVER,
                                   segmented_button_unselected_color=CARD,
                                   segmented_button_unselected_hover_color=SECONDARY, text_color=TEXT)
        self.tabs.pack(fill="both", expand=True, padx=14, pady=(2, 12))
        try:  # larger tab bar (internal widget, therefore guarded)
            self.tabs._segmented_button.configure(height=38, font=ctk.CTkFont(size=14, weight="bold"))
        except Exception:  # noqa: BLE001
            pass
        for name in self._tab_names:
            self.tabs.add(name)
            self.tabs.tab(name).columnconfigure(0, weight=1)
        self._tab_run(self.tabs.tab(self._tab_names[0]))
        self._tab_preview(self.tabs.tab(self._tab_names[1]))
        self._tab_agent(self.tabs.tab(self._tab_names[2]))

    # --- tab 1
    def _tab_run(self, tab):
        src = self._card(tab, self.t("card_src"), row=0)
        ctk.CTkLabel(src, text=self.t("lbl_project")).grid(row=1, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkEntry(src, textvariable=self.var_in, placeholder_text=self.t("ph_project"),
                     height=34, corner_radius=10).grid(row=1, column=1, sticky="ew", pady=6)
        self._button(src, self.t("btn_choose"), self._pick_in).grid(row=1, column=2, padx=(10, 16), pady=6)
        ctk.CTkLabel(src, text=self.t("lbl_outdir")).grid(row=2, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkEntry(src, textvariable=self.var_out, placeholder_text=self.t("ph_outdir"),
                     height=34, corner_radius=10).grid(row=2, column=1, sticky="ew", pady=6)
        self._button(src, self.t("btn_choose"), self._pick_out).grid(row=2, column=2, padx=(10, 16), pady=6)
        ctk.CTkLabel(src, text=self.t("lbl_filename")).grid(row=3, column=0, sticky="w", padx=(16, 10), pady=(6, 14))
        ctk.CTkComboBox(src, variable=self.var_name, height=34, corner_radius=10,
                        values=["PROJECT_SUMMARY.md"] + AGENT_FILES[:3] + ["CONTEXT.md"],
                        button_color=ACCENT, button_hover_color=ACCENT_HOVER
                        ).grid(row=3, column=1, sticky="ew", pady=(6, 14))

        opt = self._card(tab, self.t("card_detail"), row=1)
        ctk.CTkLabel(opt, text=self.t("lbl_depth")).grid(row=1, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkSlider(opt, from_=1, to=8, number_of_steps=7, variable=self.var_depth, command=self._update_labels,
                      button_color=ACCENT, button_hover_color=ACCENT_HOVER, progress_color=ACCENT
                      ).grid(row=1, column=1, sticky="ew", pady=6)
        self.lbl_depth = ctk.CTkLabel(opt, text="", width=60, anchor="e")
        self.lbl_depth.grid(row=1, column=2, padx=(10, 16))
        ctk.CTkLabel(opt, text=self.t("lbl_files")).grid(row=2, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkSlider(opt, from_=10, to=300, number_of_steps=29, variable=self.var_files, command=self._update_labels,
                      button_color=ACCENT, button_hover_color=ACCENT_HOVER, progress_color=ACCENT
                      ).grid(row=2, column=1, sticky="ew", pady=6)
        self.lbl_files = ctk.CTkLabel(opt, text="", width=60, anchor="e")
        self.lbl_files.grid(row=2, column=2, padx=(10, 16))

        ctk.CTkSwitch(opt, text=self.t("sw_llm"), variable=self.var_llm, command=self._toggle_llm,
                      progress_color=ACCENT).grid(row=3, column=0, columnspan=3, sticky="w", padx=16, pady=(8, 6))
        self.llm_frame = ctk.CTkFrame(opt, fg_color="transparent")
        self.llm_frame.grid(row=4, column=0, columnspan=3, sticky="ew", padx=16, pady=(0, 12))
        self.llm_frame.columnconfigure(1, weight=1)
        ctk.CTkLabel(self.llm_frame, text=self.t("lbl_url"), text_color=MUTED).grid(row=0, column=0, sticky="w", padx=(0, 10), pady=3)
        ctk.CTkEntry(self.llm_frame, textvariable=self.var_url, height=32, corner_radius=10
                     ).grid(row=0, column=1, sticky="ew", pady=3)
        ctk.CTkLabel(self.llm_frame, text=self.t("lbl_model"), text_color=MUTED).grid(row=1, column=0, sticky="w", padx=(0, 10), pady=3)
        ctk.CTkEntry(self.llm_frame, textvariable=self.var_model, height=32, corner_radius=10
                     ).grid(row=1, column=1, sticky="ew", pady=3)

        run = ctk.CTkFrame(tab, fg_color="transparent")
        run.grid(row=2, column=0, sticky="ew", pady=(4, 0))
        run.columnconfigure(1, weight=1)
        self.btn_run = self._button(run, self.t("btn_run"), self._run, primary=True, width=190, height=42)
        self.btn_run.grid(row=0, column=0)
        self.progress = ctk.CTkProgressBar(run, mode="determinate", progress_color=ACCENT, height=8)
        self.progress.grid(row=0, column=1, sticky="ew", padx=16)
        self.progress.set(0)
        self.lbl_status = ctk.CTkLabel(tab, text="", text_color=MUTED, anchor="w", justify="left", wraplength=700)
        self.lbl_status.grid(row=3, column=0, sticky="ew", pady=(10, 0), padx=4)

    # --- tab 2
    def _tab_preview(self, tab):
        tab.rowconfigure(0, weight=1)
        self.txt_preview = ctk.CTkTextbox(tab, corner_radius=14, fg_color=CARD, wrap="none",
                                          font=ctk.CTkFont(family="monospace", size=12))
        self.txt_preview.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        self._set_text(self.txt_preview, self.preview_text if self.preview_text else self.t("prev_empty"))
        row = ctk.CTkFrame(tab, fg_color="transparent")
        row.grid(row=1, column=0, sticky="ew")
        row.columnconfigure(3, weight=1)
        self.btn_copy = self._button(row, self.t("btn_copy"),
                                     lambda: self._copy(self._get_text(self.txt_preview), "copied_prev"),
                                     primary=True, state="disabled")
        self.btn_copy.grid(row=0, column=0, padx=(0, 8))
        self.btn_open = self._button(row, self.t("btn_openout"), self._open_out, width=190, state="disabled")
        self.btn_open.grid(row=0, column=1, padx=(0, 8))
        info = self.t("prev_info", lines=self.preview_info[0], tokens=self.preview_info[1]) if self.preview_info else ""
        self.lbl_info = ctk.CTkLabel(row, text=info, text_color=MUTED)
        self.lbl_info.grid(row=0, column=3, sticky="e")

    # --- tab 3
    def _tab_agent(self, tab):
        ctk.CTkLabel(tab, justify="left", anchor="w", wraplength=700, text_color=MUTED, text=self.t("agent_intro")
                     ).grid(row=0, column=0, sticky="ew", padx=4, pady=(2, 10))

        card = self._card(tab, self.t("card_agent1"), row=1)
        ctk.CTkLabel(card, text=self.t("lbl_project")).grid(row=1, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkEntry(card, textvariable=self.var_agent_dir, placeholder_text=self.t("ph_agent_dir"),
                     height=34, corner_radius=10).grid(row=1, column=1, sticky="ew", pady=6)
        self._button(card, self.t("btn_choose"), self._pick_agent_dir).grid(row=1, column=2, padx=(10, 16), pady=6)
        ctk.CTkLabel(card, text=self.t("lbl_agent_file")).grid(row=2, column=0, sticky="w", padx=(16, 10), pady=6)
        ctk.CTkComboBox(card, variable=self.var_agent_file, values=AGENT_FILES, height=34, corner_radius=10,
                        button_color=ACCENT, button_hover_color=ACCENT_HOVER
                        ).grid(row=2, column=1, sticky="ew", pady=6)
        self._button(card, self.t("btn_write"), self._write_agent, primary=True, width=190, height=36
                     ).grid(row=3, column=0, columnspan=3, sticky="w", padx=16, pady=(8, 4))
        self.lbl_agent = ctk.CTkLabel(card, text="", text_color=MUTED, anchor="w", justify="left", wraplength=680)
        self.lbl_agent.grid(row=4, column=0, columnspan=3, sticky="ew", padx=16, pady=(0, 14))

        mcp = self._card(tab, self.t("card_agent2"), row=2)
        ctk.CTkLabel(mcp, text=self.t("mcp_hint"), text_color=MUTED
                     ).grid(row=1, column=0, columnspan=3, sticky="w", padx=16, pady=(0, 6))
        self.txt_mcp = ctk.CTkTextbox(mcp, height=170, corner_radius=10, wrap="none",
                                      font=ctk.CTkFont(family="monospace", size=12))
        self.txt_mcp.grid(row=2, column=0, columnspan=3, sticky="ew", padx=16)
        self._set_text(self.txt_mcp, agent_setup.mcp_config_json())
        self._button(mcp, self.t("btn_copy_mcp"), lambda: self._copy(agent_setup.mcp_config_json(), "copied_mcp"),
                     width=210).grid(row=3, column=0, columnspan=3, sticky="w", padx=16, pady=(10, 14))

    # ------------------------------------------------------------ small helpers
    @staticmethod
    def _set_text(box, text):
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", text)
        box.configure(state="disabled")

    @staticmethod
    def _get_text(box):
        return box.get("1.0", "end").rstrip("\n")

    def _copy(self, text, msg_key):
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update()
        self._status(key=msg_key, ok=True)

    def _status(self, key=None, raw=None, ok=None, **kw):
        self._st = (key, raw, ok, kw)
        self._render_status()

    def _render_status(self):
        key, raw, ok, kw = self._st
        text = self.t(key, **kw) if key else (raw or "")
        color = MUTED if ok is None else (OK if ok else ERR)
        self.lbl_status.configure(text=text, text_color=color)

    def _agent_status(self, key=None, raw=None, ok=None, **kw):
        self._agent_st = (key, raw, ok, kw)
        self._render_agent_status()

    def _render_agent_status(self):
        key, raw, ok, kw = self._agent_st
        if key == "agent_done":
            kw = dict(kw, action=agent_setup.MSG[self.lang][kw["action_key"]])
        text = self.t(key, **kw) if key else (raw or "")
        color = MUTED if ok is None else (OK if ok else ERR)
        self.lbl_agent.configure(text=text, text_color=color)

    def _update_labels(self, *_):
        self.lbl_depth.configure(text=str(int(self.var_depth.get())))
        self.lbl_files.configure(text=str(int(self.var_files.get())))

    def _toggle_llm(self):
        if self.var_llm.get():
            self.llm_frame.grid()
        else:
            self.llm_frame.grid_remove()

    def _on_mode(self, label):
        self.mode = self._mode_labels.get(label, "dark")
        ctk.set_appearance_mode(self.mode)
        self.cfg["mode"] = self.mode
        save_config(self.cfg)

    def _confirm(self, text) -> bool:
        res = {"ok": False}
        top = ctk.CTkToplevel(self, fg_color=BG)
        top.title(APP_TITLE)
        top.geometry("480x170")
        top.resizable(False, False)
        top.transient(self)
        ctk.CTkLabel(top, text=text, wraplength=440, justify="left").pack(padx=20, pady=(22, 12), fill="x")
        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(pady=8)

        def done(v):
            res["ok"] = v
            top.destroy()

        self._button(row, self.t("btn_cancel"), lambda: done(False)).pack(side="left", padx=6)
        self._button(row, self.t("btn_overwrite"), lambda: done(True), primary=True, width=140).pack(side="left", padx=6)
        top.protocol("WM_DELETE_WINDOW", lambda: done(False))
        top.after(150, lambda: (top.lift(), top.focus_force(), top.grab_set()))
        self.wait_window(top)
        return res["ok"]

    # ------------------------------------------------------------ actions
    def _pick_in(self):
        d = pick_dir(self.t("dlg_project"), self.var_in.get())
        if d:
            self.var_in.set(d)
            if not self.var_agent_dir.get():
                self.var_agent_dir.set(d)

    def _pick_out(self):
        d = pick_dir(self.t("dlg_out"), self.var_out.get() or self.var_in.get())
        if d:
            self.var_out.set(d)

    def _pick_agent_dir(self):
        d = pick_dir(self.t("dlg_agent"), self.var_agent_dir.get() or self.var_in.get())
        if d:
            self.var_agent_dir.set(d)

    def _open_out(self):
        if self.last_output and not open_folder(Path(self.last_output).parent):
            self._status(raw=str(Path(self.last_output).parent))

    def _write_agent(self):
        folder, fname = self.var_agent_dir.get().strip(), self.var_agent_file.get().strip()
        if not folder:
            self._agent_status("agent_choose", ok=False)
            return
        try:
            path, action = agent_setup.write_agent_block(folder, fname, self.lang)
        except (ValueError, OSError) as e:
            self._agent_status(raw=f"{e}", ok=False)
            return
        self.cfg.update(agent_dir=folder, agent_file=fname)
        save_config(self.cfg)
        self._agent_status("agent_done", ok=True, name=path.name, action_key=action, path=path)

    def _run(self):
        src = self.var_in.get().strip()
        if not src or not Path(src).is_dir():
            self._status("err_folder", ok=False)
            return
        out_dir = self.var_out.get().strip() or src
        name = self.var_name.get().strip() or "PROJECT_SUMMARY.md"
        if "/" in name or name in (".", ".."):
            self._status("err_name", ok=False)
            return
        try:
            Path(out_dir).mkdir(parents=True, exist_ok=True)
        except OSError as e:
            self._status("err_outdir", ok=False, e=e)
            return
        out_path = Path(out_dir) / name
        if out_path.exists() and not self._confirm(self.t("confirm", path=out_path)):
            return

        depth, nfiles = int(self.var_depth.get()), int(self.var_files.get())
        argv = ["summarize_folder.py", src, "-o", str(out_path), "--max-depth", str(depth),
                "--max-files", str(nfiles), "--lang", self.lang]
        if self.var_llm.get():
            argv += ["--llm", "--base-url", self.var_url.get().strip(), "--model", self.var_model.get().strip()]

        self.cfg.update(input=src, output=self.var_out.get().strip(), name=name, depth=depth, files=nfiles,
                        llm=self.var_llm.get(), url=self.var_url.get().strip(), model=self.var_model.get().strip(),
                        lang=self.lang, mode=self.mode)
        save_config(self.cfg)

        self.running = True
        self.btn_run.configure(state="disabled", text=self.t("btn_running"))
        self.btn_open.configure(state="disabled")
        self.btn_copy.configure(state="disabled")
        self._status("st_working")
        self.progress.configure(mode="indeterminate")
        self.progress.start()
        self.last_output = str(out_path)
        threading.Thread(target=self._work, args=(argv,), daemon=True).start()

    def _work(self, argv):
        writer = QueueWriter(self.q)
        status, old_argv = "ok", sys.argv
        try:
            sys.argv = argv
            with contextlib.redirect_stdout(writer), contextlib.redirect_stderr(writer):
                summarize_folder.main()
        except SystemExit as e:
            if e.code not in (None, 0):
                self.q.put(("log", f"{e.code}\n"))
                status = "error"
        except Exception as e:  # noqa: BLE001
            self.q.put(("log", f"{e}\n"))
            status = "error"
        finally:
            sys.argv = old_argv
        self.q.put(("done", status))

    def _poll(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    line = payload.strip().splitlines()[-1] if payload.strip() else ""
                    if line:
                        self._status(raw=line)
                elif kind == "done":
                    self.running = False
                    self.progress.stop()
                    self.progress.configure(mode="determinate")
                    self.progress.set(1 if payload == "ok" else 0)
                    self.btn_run.configure(state="normal", text=self.t("btn_run"))
                    self._finish(payload == "ok")
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _finish(self, ok: bool):
        if not ok:
            self._status(raw=self._st[1] or self.t("err_generic"), ok=False)
            return
        try:
            text = Path(self.last_output).read_text(encoding="utf-8")
        except OSError as e:
            self._status("err_read", ok=False, e=e)
            return
        self.preview_text = text
        self.preview_info = (len(text.splitlines()), len(text) // 4)
        self.result_ready = True
        self._set_text(self.txt_preview, text)
        self.lbl_info.configure(text=self.t("prev_info", lines=self.preview_info[0], tokens=self.preview_info[1]))
        self.btn_open.configure(state="normal")
        self.btn_copy.configure(state="normal")
        self._status("st_done", ok=True, path=self.last_output)
        self.tabs.set(self._tab_names[1])

    def _close(self):
        self.destroy()


def main():
    App().mainloop()


if __name__ == "__main__":
    main()

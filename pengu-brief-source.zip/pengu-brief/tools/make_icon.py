#!/usr/bin/env python3
"""Zeichnet das Pengu-Brief-Icon (Pinguin mit Briefumschlag) als PNG. Benoetigt Pillow."""
import sys

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "pengu-brief.png"
SIZE = int(sys.argv[2]) if len(sys.argv) > 2 else 512
SS = 2048          # Zeichenflaeche (wird runterskaliert -> glatte Kanten)
K = SS / 256       # Koordinaten sind in 256er-Raum angegeben


def s(*vals):
    return [v * K for v in vals]


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# Hintergrund: vertikaler Verlauf (Nachthimmel -> Eismeer), als abgerundetes Quadrat
top, bottom = (36, 52, 102), (14, 116, 144)
grad = Image.new("RGB", (SS, SS))
gd = ImageDraw.Draw(grad)
for y in range(SS):
    gd.line([(0, y), (SS, y)], fill=lerp(top, bottom, y / SS))
mask = Image.new("L", (SS, SS), 0)
ImageDraw.Draw(mask).rounded_rectangle(s(8, 8, 248, 248), radius=56 * K, fill=255)
img = Image.new("RGBA", (SS, SS), (0, 0, 0, 0))
img.paste(grad, (0, 0), mask)

# Ebene mit allem, was oben drauf liegt (damit Transparenz sauber gemischt wird)
over = Image.new("RGBA", (SS, SS), (0, 0, 0, 0))
d = ImageDraw.Draw(over)

# Sterne
for x, y, r in [(46, 40, 2.4), (206, 52, 2), (176, 30, 1.6), (70, 74, 1.6), (214, 100, 1.8)]:
    d.ellipse(s(x - r, y - r, x + r, y + r), fill=(255, 255, 255, 200))

# Eisscholle
d.ellipse(s(40, 196, 216, 236), fill=(226, 240, 250, 255))
d.ellipse(s(52, 200, 204, 228), fill=(200, 224, 242, 255))

# Pinguin: Fluegel, Koerper, Bauch
d.ellipse(s(50, 112, 90, 190), fill=(18, 24, 40, 255))
d.ellipse(s(166, 112, 206, 190), fill=(18, 24, 40, 255))
d.ellipse(s(66, 50, 190, 212), fill=(22, 30, 48, 255))
d.ellipse(s(88, 104, 168, 206), fill=(246, 249, 252, 255))

# Gesicht: zwei weisse Loben, Augen, Schnabel
d.ellipse(s(86, 66, 130, 112), fill=(246, 249, 252, 255))
d.ellipse(s(126, 66, 170, 112), fill=(246, 249, 252, 255))
for cx in (110, 146):
    d.ellipse(s(cx - 7.5, 82.5, cx + 7.5, 97.5), fill=(15, 20, 32, 255))
    d.ellipse(s(cx - 2.5 + 2, 85, cx + 2.5 + 2, 90), fill=(255, 255, 255, 255))
d.polygon(s(118, 100, 138, 100, 128, 116), fill=(255, 165, 31, 255))
# Wangen
d.ellipse(s(94, 100, 108, 110), fill=(255, 150, 150, 120))
d.ellipse(s(148, 100, 162, 110), fill=(255, 150, 150, 120))

# Fuesse
d.ellipse(s(84, 202, 122, 222), fill=(255, 165, 31, 255))
d.ellipse(s(134, 202, 172, 222), fill=(255, 165, 31, 255))

# Briefumschlag (rechts unten, leicht ueberlappend)
d.rounded_rectangle(s(142, 150, 226, 204), radius=7 * K, fill=(255, 255, 255, 255), outline=(203, 213, 225, 255), width=int(2 * K))
d.line(s(144, 154, 184, 182, 224, 154), fill=(148, 163, 184, 255), width=int(3.5 * K), joint="curve")
d.ellipse(s(177, 175, 191, 189), fill=(31, 182, 201, 255))

img = Image.alpha_composite(img, over)
img = img.resize((SIZE, SIZE), Image.LANCZOS)
img.save(OUT)
print(f"{OUT} ({SIZE}x{SIZE}) geschrieben")
